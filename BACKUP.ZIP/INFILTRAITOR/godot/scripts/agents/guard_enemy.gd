extends Node2D
class_name GuardEnemy
## Patrol guard placeholder: draw-based enemy with directional vision checks.

signal move_started(from_cell: Vector2i, to_cell: Vector2i)
signal step_finished(cell: Vector2i)
signal move_finished(cell: Vector2i)

const TILE_CENTER_OFFSET := Vector2(0.0, 64.0)
const STEP_DURATION_BASE := 0.13

const COLOR_BODY := Color(0.86, 0.26, 0.22, 1.0)
const COLOR_BODY_DARK := Color(0.58, 0.12, 0.10, 1.0)
const COLOR_HEAD := Color(1.0, 0.87, 0.80, 1.0)
const COLOR_SHADOW := Color(0.0, 0.0, 0.0, 0.28)

## Probabilidades base por distância — espelha TicSystem.DETECTION_CURVE
const FOV_DISTANCE_CURVE: Array[float] = [
	1.00, 1.00, 0.95, 0.85, 0.60, 0.40, 0.15, 0.05, 0.01
]

## Multiplicador lateral por distância ao eixo central do cone (em tiles)
## offset 0 = coluna central, offset 1 = ±1 coluna, offset 2 = ±2 colunas
const FOV_LATERAL_FALLOFF: Array[float] = [1.0, 0.45, 0.08]

const CARDINAL_DIRS := [Vector2i.UP, Vector2i.RIGHT, Vector2i.DOWN, Vector2i.LEFT]
const VISION_RANGE := 6
const VISION_CONE_RADIUS := 6
const VISION_CONE_HALF_WIDTH_TILES := 3
const STATE_PATROL := "patrol"
const STATE_SUSPICIOUS := "suspicious"
const STATE_ALERT := "alert"
const STATE_CHASE := "chase"
const INVALID_CELL: Vector2i = Vector2i(-9999, -9999)

var floor_layer: TileMapLayer = null
var visual_offset: Vector2 = Vector2.ZERO
var enemy_id: String = ""

var cell: Vector2i = Vector2i.ZERO
var patrol_route: Array[Vector2i] = []
var patrol_index: int = 0
var facing: Vector2i = Vector2i.UP
var state: String = STATE_PATROL
var state_timer: int = 0
var last_known_agent_cell: Vector2i = INVALID_CELL
var is_moving: bool = false
var _path_queue: Array[Vector2i] = []

## Angular FOV detection
var fov_degrees: float = 90.0      ## full cone width in degrees
var fov_range: int = 8             ## max detection range in tiles
var facing_angle_deg: float = 0.0  ## 0=UP 90=RIGHT 180=DOWN 270=LEFT

## A* path caching
var _cached_target: Vector2i = INVALID_CELL
var _cached_path: Array[Vector2i] = []
var _path_index: int = 1

## Dev vision mode
var dev_vision: bool = false

## Dev 05: detection meter — 0.0 to 1.0, placeholder until M2 fills it
var detection: float = 0.0

## M2-03: Patrulha Orgânica — idle behavior e rotação de olhar
var idle_turns_remaining: int = 0
var _look_angles: Array[float] = [0.0, 45.0, 90.0, 135.0, 180.0, 225.0, 270.0, 315.0]

## Debug label for dev_vision mode
var _debug_label_container: Panel = null
var _debug_label: Label = null


func set_dev_vision(enabled: bool) -> void:
	dev_vision = enabled
	_update_debug_label()
	queue_redraw()


func setup(
		tile_layer: TileMapLayer,
		offset: Vector2,
		id: String,
		route: Array[Vector2i],
		start_index: int = 0
) -> void:
	floor_layer = tile_layer
	visual_offset = offset
	enemy_id = id
	patrol_route = route.duplicate()
	if patrol_route.is_empty():
		patrol_route = [Vector2i.ZERO]

	patrol_index = wrapi(start_index, 0, patrol_route.size())
	cell = patrol_route[patrol_index]
	position = _cell_to_world(cell)
	_set_facing_from_route()
	_update_facing_angle()
	
	## Create debug label container with background for dev_vision mode
	_debug_label_container = Panel.new()
	_debug_label_container.custom_minimum_size = Vector2(250, 200)
	var panel_style = StyleBoxFlat.new()
	panel_style.bg_color = Color(0.15, 0.15, 0.15, 0.95)  ## Dark gray background
	panel_style.set_corner_radius_all(4)
	panel_style.set_content_margin_all(30)
	_debug_label_container.add_theme_stylebox_override("panel", panel_style)
	_debug_label_container.z_index = 100
	_debug_label_container.visible = false
	add_child(_debug_label_container)
	
	## Create debug label inside container
	_debug_label = Label.new()
	_debug_label.set_position(Vector2(+15, 0))
	_debug_label.add_theme_font_size_override("font_size", 24)
	_debug_label.add_theme_color_override("font_color", Color.WHITE)
	_debug_label.text_overrun_behavior = TextServer.OVERRUN_NO_TRIMMING
	_debug_label_container.add_child(_debug_label)
	
	queue_redraw()


func reset_to_route_start() -> void:
	if patrol_route.is_empty():
		return
	patrol_index = 0
	cell = patrol_route[patrol_index]
	position = _cell_to_world(cell)
	_set_facing_from_route()
	_update_facing_angle()
	queue_redraw()


func evaluate_detection(player_cell: Vector2i, _vision_range: int = VISION_RANGE, blocked_cells: Dictionary = {}, blocked_edges: Dictionary = {}, _close_warning_range: int = 2) -> Dictionary:
	var delta := player_cell - cell
	if delta == Vector2i.ZERO:
		return {"visible": true, "severity": 2, "distance": 0, "angle_ratio": 1.0}

	var dist := absi(delta.x) + absi(delta.y)
	if dist > fov_range:
		return {"visible": false, "severity": 0}

	var to_target_angle := rad_to_deg(atan2(float(delta.x), float(-delta.y)))
	var angle_diff := wrapf(to_target_angle - facing_angle_deg, -180.0, 180.0)
	var half_fov := fov_degrees / 2.0
	if absf(angle_diff) > half_fov:
		return {"visible": false, "severity": 0}

	if blocked_cells != null and blocked_edges != null:
		if not can_see_cell(player_cell, blocked_cells, blocked_edges):
			return {"visible": false, "severity": 0}

	var angle_ratio := 1.0 - (absf(angle_diff) / half_fov)
	var severity := 2 if dist <= 2 else 1
	return {"visible": true, "severity": severity, "distance": dist, "angle_ratio": angle_ratio}


func pick_next_patrol_cell(
		occupied_cells: Dictionary,
		blocked_cells: Dictionary,
		blocked_edges: Dictionary,
		room_size: Vector2i
) -> Vector2i:
	if patrol_route.size() < 2:
		return cell

	for i in range(1, patrol_route.size() + 1):
		var idx := (patrol_index + i) % patrol_route.size()
		var candidate: Vector2i = patrol_route[idx]
		if not _is_inside(candidate, room_size):
			continue
		if blocked_cells.has(candidate):
			continue
		if occupied_cells.has(candidate):
			continue
		if _is_edge_blocked(cell, candidate, blocked_edges):
			continue
		if candidate == cell:
			continue
		patrol_index = idx
		return candidate

	return cell


func move_to_cell_animated(
		new_cell: Vector2i,
		blocked_cells: Dictionary,
		blocked_edges: Dictionary,
		room_size: Vector2i
) -> void:
	if new_cell == cell:
		return
	var path: Array[Vector2i] = GuardPathfinder.find_path(cell, new_cell, blocked_cells, blocked_edges, room_size)
	if path.size() < 2:
		return
	move_along_path(path)


func move_along_path(path: Array[Vector2i]) -> void:
	if path.size() < 2:
		return
	is_moving = true
	move_started.emit(path[0], path.back())
	_path_queue = path.duplicate()
	_path_queue.pop_front()
	_step_next()


func _step_next() -> void:
	if _path_queue.is_empty():
		is_moving = false
		move_finished.emit(cell)
		queue_redraw()
		return

	var next_cell: Vector2i = _path_queue.pop_front()
	var previous_cell: Vector2i = cell
	cell = next_cell
	facing = _snap_to_cardinal(next_cell - previous_cell)
	_update_facing_angle()
	_update_debug_label()
	var tween := create_tween()
	tween.set_trans(Tween.TRANS_SINE)
	tween.set_ease(Tween.EASE_IN_OUT)
	tween.tween_property(self, "position", _cell_to_world(next_cell), _get_step_duration())
	await tween.finished
	step_finished.emit(next_cell)
	queue_redraw()
	_step_next()



func _cell_to_world(map_cell: Vector2i) -> Vector2:
	if floor_layer == null:
		return Vector2.ZERO
	return floor_layer.map_to_local(map_cell) + TILE_CENTER_OFFSET + visual_offset


func _set_facing_from_route() -> void:
	if patrol_route.size() < 2:
		facing = Vector2i.UP
		_update_facing_angle()
		return
	var next_idx := (patrol_index + 1) % patrol_route.size()
	var dir := patrol_route[next_idx] - patrol_route[patrol_index]
	if dir == Vector2i.ZERO:
		facing = Vector2i.UP
		_update_facing_angle()
		return
	facing = _snap_to_cardinal(dir)
	_update_facing_angle()


func _get_step_duration() -> float:
	match state:
		STATE_PATROL:
			return STEP_DURATION_BASE * 2.2
		STATE_SUSPICIOUS:
			return STEP_DURATION_BASE * 1.4
		STATE_ALERT:
			return STEP_DURATION_BASE * 1.0
		STATE_CHASE:
			return STEP_DURATION_BASE * 0.75
	return STEP_DURATION_BASE


func _snap_to_cardinal(v: Vector2i) -> Vector2i:
	if abs(v.x) >= abs(v.y):
		return Vector2i.RIGHT if v.x >= 0 else Vector2i.LEFT
	return Vector2i.DOWN if v.y >= 0 else Vector2i.UP


func _update_facing_angle() -> void:
	if facing == Vector2i.UP:
		facing_angle_deg = 0.0
	elif facing == Vector2i.RIGHT:
		facing_angle_deg = 90.0
	elif facing == Vector2i.DOWN:
		facing_angle_deg = 180.0
	elif facing == Vector2i.LEFT:
		facing_angle_deg = 270.0


func _update_facing_from_angle() -> void:
	var snapped_angle := snappedf(facing_angle_deg, 45.0)
	match int(snapped_angle) % 360:
		0:
			facing = Vector2i.UP
		45:
			facing = Vector2i(1, -1)
		90:
			facing = Vector2i.RIGHT
		135:
			facing = Vector2i(1,  1)
		180:
			facing = Vector2i.DOWN
		225:
			facing = Vector2i(-1, 1)
		270:
			facing = Vector2i.LEFT
		315:
			facing = Vector2i(-1, -1)
	queue_redraw()


## Converte probabilidade de detecção em cor do cone (vermelho → verde)
## alpha_mult: multiplicador de opacidade por estado do guarda (0.4 relaxado → 1.0 chase)
static func _prob_to_color(prob: float, alpha_mult: float = 1.0) -> Color:
	var c: Color
	if prob >= 0.95:
		c = Color(1.00, 0.13, 0.13, 0.85)  ## Vermelho
	elif prob >= 0.80:
		c = Color(1.00, 0.40, 0.00, 0.75)  ## Laranja escuro
	elif prob >= 0.55:
		c = Color(1.00, 0.63, 0.00, 0.65)  ## Laranja
	elif prob >= 0.35:
		c = Color(1.00, 0.82, 0.00, 0.55)  ## Amarelo
	elif prob >= 0.12:
		c = Color(0.78, 0.88, 0.00, 0.45)  ## Amarelo-verde
	elif prob >= 0.03:
		c = Color(0.50, 0.82, 0.00, 0.35)  ## Verde claro
	else:
		c = Color(0.25, 0.75, 0.00, 0.25)  ## Verde escuro
	c.a *= alpha_mult
	return c


## Retorna parâmetros visuais do cone por estado do guarda
## O cone visual é intencionalmente menor que o cone de detecção real:
## o jogador vê menos do que o guarda percebe, criando margem de risco oculto.
func _get_cone_visual_params() -> Dictionary:
	match state:
		STATE_PATROL:
			return {"range": 5, "fov": 70.0, "alpha": 0.4, "prob_mult": 0.6}
		STATE_SUSPICIOUS:
			return {"range": 7, "fov": 90.0, "alpha": 0.8, "prob_mult": 1.8}
		STATE_ALERT:
			return {"range": 8, "fov": 100.0, "alpha": 0.95, "prob_mult": 2.2}
		STATE_CHASE:
			return {"range": 8, "fov": 110.0, "alpha": 1.0, "prob_mult": 3.0}
	## Default (relaxado)
	return {"range": 5, "fov": 70.0, "alpha": 0.4, "prob_mult": 0.6}


## Retorna Array de {delta: Vector2i, prob: float} para todos os tiles no cone de visão
func _get_cone_tiles() -> Array:
	var params       := _get_cone_visual_params()
	var vis_range: int   = params["range"]
	var vis_fov: float   = params["fov"]
	var prob_mult: float = params["prob_mult"]
	var half_fov := vis_fov / 2.0
	var tiles := []

	for dx in range(-vis_range, vis_range + 1):
		for dy in range(-vis_range, vis_range + 1):
			if dx == 0 and dy == 0:
				continue
			var delta := Vector2i(dx, dy)
			var dist := absi(dx) + absi(dy)
			if dist > vis_range:
				continue

			## Verificação angular
			var to_angle := rad_to_deg(atan2(float(dx), float(-dy)))
			var angle_diff := wrapf(to_angle - facing_angle_deg, -180.0, 180.0)
			if absf(angle_diff) > half_fov:
				continue

			## Probabilidade base pela distância
			var base_prob: float = FOV_DISTANCE_CURVE[dist] if dist < FOV_DISTANCE_CURVE.size() else 0.0

			## Multiplicador lateral por distância ao eixo central
			var lateral_offset := absf(angle_diff) / half_fov  ## 0.0 no centro, 1.0 na borda
			var lateral_idx := mini(int(lateral_offset * FOV_LATERAL_FALLOFF.size()), FOV_LATERAL_FALLOFF.size() - 1)
			var lateral_mult := FOV_LATERAL_FALLOFF[lateral_idx]

			var final_prob := base_prob * lateral_mult * prob_mult

			tiles.append({"delta": delta, "prob": final_prob})

	return tiles


func _update_debug_label() -> void:
	if _debug_label_container == null:
		return

	_debug_label_container.visible = dev_vision

	if not dev_vision:
		return

	## Position: well above the guard's head in local coordinates
	## -320 in Y places label far above the sprite, no overlap
	_debug_label_container.position = Vector2(-150.0, -350.0)

	var last := "—"
	if last_known_agent_cell != INVALID_CELL:
		last = "%d,%d" % [last_known_agent_cell.x, last_known_agent_cell.y]

	_debug_label.text = (
		"id: %s\n" % enemy_id +
		"state: %s\n" % state +
		"cell: %d,%d\n" % [cell.x, cell.y] +
		"facing: %s\n" % _facing_name() +
		"last_known: %s" % last
	)


func _facing_name() -> String:
	if facing == Vector2i.UP:
		return "N"
	if facing == Vector2i.DOWN:
		return "S"
	if facing == Vector2i.RIGHT:
		return "E"
	if facing == Vector2i.LEFT:
		return "W"
	return "?"


func _is_inside(pos: Vector2i, room_size: Vector2i) -> bool:
	return pos.x >= 0 and pos.y >= 0 and pos.x < room_size.x and pos.y < room_size.y


func _is_edge_blocked(from_cell: Vector2i, to_cell: Vector2i, blocked_edges: Dictionary) -> bool:
	var key := WallEdgeData.edge_key(from_cell, to_cell)
	return blocked_edges.has(key)


func can_see_cell(target_cell: Vector2i, blocked_cells: Dictionary, blocked_edges: Dictionary) -> bool:
	var current: Vector2i = cell
	var dx := target_cell.x - current.x
	var dy := target_cell.y - current.y
	var step_x: int = 0
	if dx > 0:
		step_x = 1
	elif dx < 0:
		step_x = -1
	var step_y: int = 0
	if dy > 0:
		step_y = 1
	elif dy < 0:
		step_y = -1
	var abs_dx: int = abs(dx)
	var abs_dy: int = abs(dy)
	var err: int = abs_dx - abs_dy

	while current != target_cell:
		var e2 := err * 2
		var next_cell := current
		if e2 > -abs_dy:
			next_cell.x += step_x
			err -= abs_dy
		if e2 < abs_dx:
			next_cell.y += step_y
			err += abs_dx
		if _is_edge_blocked(current, next_cell, blocked_edges):
			return false
		if blocked_cells.has(next_cell) and next_cell != target_cell:
			return false
		current = next_cell
	return true


func _enter_state(new_state: String) -> void:
	state = new_state
	if new_state != STATE_PATROL:
		idle_turns_remaining = 0
	queue_redraw()


func observe_player(player_visible: bool, severity: int, player_cell: Vector2i) -> void:
	if player_visible:
		last_known_agent_cell = player_cell
		if severity >= 2:
			_enter_state(STATE_ALERT)
			state_timer = 3
		elif state != STATE_ALERT:
			_enter_state(STATE_SUSPICIOUS)
			state_timer = 3
	_update_debug_label()
	return


## M2-05: Reage a barulho percebido — detecção auditiva
## perceived_intensity: intensidade após atenuação por distância e paredes
func hear_noise(noise_tile: Vector2i, perceived_intensity: float) -> void:
	if perceived_intensity >= 0.6:
		## Barulho alto — guarda vai investigar diretamente
		last_known_agent_cell = noise_tile
		if state == STATE_PATROL:
			_enter_state(STATE_SUSPICIOUS)
			state_timer = 3
	elif perceived_intensity >= 0.25:
		## Barulho médio — guarda fica tenso mas não sabe onde
		if state == STATE_PATROL:
			_enter_state(STATE_SUSPICIOUS)
			state_timer = 2
	## Barulho fraco (< 0.25): ignorado


func tick_state() -> void:
	if state == STATE_PATROL:
		return
	state_timer -= 1
	if state_timer <= 0:
		if state == STATE_ALERT:
			_enter_state(STATE_CHASE)
			state_timer = 3
		elif state == STATE_SUSPICIOUS:
			_enter_state(STATE_PATROL)
			last_known_agent_cell = INVALID_CELL
		elif state == STATE_CHASE:
			_enter_state(STATE_SUSPICIOUS)
			state_timer = 2

	## Dev 05: placeholder detection mapping — M2 will override with real detection
	match state:
		STATE_PATROL:
			detection = 0.0
		STATE_SUSPICIOUS:
			detection = 0.35
		STATE_ALERT:
			detection = 0.65
		STATE_CHASE:
			detection = 1.0

	if dev_vision:
		queue_redraw()


func _do_idle_behavior() -> void:
	if state != STATE_PATROL:
		return

	if randf() < 0.3:
		var new_angle := _look_angles[randi() % _look_angles.size()]
		facing_angle_deg = new_angle
		_update_facing_from_angle()

	if randf() < 0.2:
		idle_turns_remaining = randi_range(1, 2)


func choose_next_cell(
		occupied_cells: Dictionary,
		blocked_cells: Dictionary,
		blocked_edges: Dictionary,
		player_cell: Vector2i,
		room_size: Vector2i
) -> Vector2i:
	if state == STATE_PATROL:
		if idle_turns_remaining > 0:
			idle_turns_remaining -= 1
			_do_idle_behavior()
			return cell

		var next := pick_next_patrol_cell(occupied_cells, blocked_cells, blocked_edges, room_size)

		if next == cell:
			_do_idle_behavior()

		return next

	if state == STATE_SUSPICIOUS:
		if last_known_agent_cell != INVALID_CELL:
			return _step_toward(last_known_agent_cell, occupied_cells, blocked_cells, blocked_edges, room_size)
		return cell
	if state == STATE_ALERT or state == STATE_CHASE:
		var target := player_cell
		if last_known_agent_cell != INVALID_CELL:
			target = last_known_agent_cell
		return _step_toward(target, occupied_cells, blocked_cells, blocked_edges, room_size)
	return cell


func _step_toward(
		target_cell: Vector2i,
		occupied_cells: Dictionary,
		blocked_cells: Dictionary,
		blocked_edges: Dictionary,
		room_size: Vector2i
) -> Vector2i:
	## Replan if target changed or path exhausted
	if target_cell != _cached_target or _path_index >= _cached_path.size():
		_cached_target = target_cell
		_cached_path = GuardPathfinder.find_path(cell, target_cell, blocked_cells, blocked_edges, room_size)
		_path_index = 1

	## No path found
	if _cached_path.is_empty():
		return cell

	## Path exhausted (shouldn't happen, but failsafe)
	if _path_index >= _cached_path.size():
		return cell

	## Get next step from path
	var next_cell: Vector2i = _cached_path[_path_index]
	_path_index += 1

	## Skip if occupied
	if occupied_cells.has(next_cell):
		return cell

	return next_cell




func _draw() -> void:
	## Cone de visão colorido por probabilidade — tile-a-tile
	var params      := _get_cone_visual_params()
	var alpha_mult: float = params["alpha"]
	var cone_tiles  := _get_cone_tiles()

	for entry in cone_tiles:
		var delta: Vector2i = entry["delta"]
		var prob: float     = entry["prob"]
		var target_cell     := cell + delta

		## LOS: pular tiles bloqueados por parede
		## Em M2 completo, esses dicts viriam da room
		if not can_see_cell(target_cell, {}, {}):
			continue

		## Posição do centro do tile em coordenadas locais
		var world_pos := _cell_to_world(target_cell) - position

		## Losango isométrico — dimensões do tile visual
		var hw := 32.0   ## half-width
		var hh := 20.0   ## half-height
		var diamond := PackedVector2Array([
			world_pos + Vector2(0.0,  -hh),
			world_pos + Vector2(hw,   0.0),
			world_pos + Vector2(0.0,   hh),
			world_pos + Vector2(-hw,  0.0),
		])
		draw_colored_polygon(diamond, _prob_to_color(prob, alpha_mult))

	var shadow := PackedVector2Array([
		Vector2(0.0, -10.0),
		Vector2(26.0, 0.0),
		Vector2(0.0, 10.0),
		Vector2(-26.0, 0.0),
	])
	draw_colored_polygon(shadow, COLOR_SHADOW)

	var body := PackedVector2Array([
		Vector2(0.0, -54.0),
		Vector2(20.0, -30.0),
		Vector2(0.0, -8.0),
		Vector2(-20.0, -30.0),
	])
	draw_colored_polygon(body, COLOR_BODY)
	draw_polyline(body + PackedVector2Array([body[0]]), COLOR_BODY_DARK, 3.0)
	draw_circle(Vector2(0.0, -62.0), 9.0, COLOR_HEAD)

	var p1 := Vector2(0.0, -82.0)
	var p2 := p1 + Vector2(facing.x * 18.0, facing.y * 12.0)
	draw_line(p1, p2, Color(1.0, 0.9, 0.5, 0.95), 3.0)

	## DEV_VISION extras — only visible when dev_vision mode is active
	if not dev_vision:
		return

	## Highlight vision cone in dev_vision mode com alpha aumentado
	var dev_alpha := minf(alpha_mult * 1.5, 1.0)
	for entry in cone_tiles:
		var delta: Vector2i = entry["delta"]
		var prob: float     = entry["prob"]
		var target_cell     := cell + delta

		if not can_see_cell(target_cell, {}, {}):
			continue

		var world_pos := _cell_to_world(target_cell) - position
		var hw := 32.0
		var hh := 20.0
		var diamond := PackedVector2Array([
			world_pos + Vector2(0.0,  -hh),
			world_pos + Vector2(hw,   0.0),
			world_pos + Vector2(0.0,   hh),
			world_pos + Vector2(-hw,  0.0),
		])
		draw_colored_polygon(diamond, _prob_to_color(prob, dev_alpha))

	## Draw patrol route as dashed line connecting waypoints
	if patrol_route.size() >= 2:
		for i in range(patrol_route.size()):
			var a := _cell_to_world(patrol_route[i]) - position
			var b := _cell_to_world(patrol_route[(i + 1) % patrol_route.size()]) - position
			draw_dashed_line(a, b, Color(0.4, 0.8, 1.0, 0.6), 2.0, 8.0)
			draw_circle(a, 5.0, Color(0.4, 0.8, 1.0, 0.8))

	## Dev 05: detection meter arc
	var arc_center := Vector2(0.0, -82.0)
	var arc_radius := 18.0
	var arc_start := PI * 1.1        ## ~200° — opens at bottom
	var arc_end := PI * 1.9          ## ~340° — closes at bottom
	var arc_steps := 24

	## Gray background arc
	draw_arc(arc_center, arc_radius, arc_start, arc_end, arc_steps,
		 Color(0.2, 0.2, 0.2, 0.7), 4.0, true)

	## Colored detection fill proportional to detection value
	if detection > 0.0:
		var filled_end := arc_start + (arc_end - arc_start) * detection
		var fill_color: Color
		if detection <= 0.35:
			fill_color = Color(1.0, 0.7, 0.1, 0.85)  ## Orange for suspicious
		elif detection <= 0.65:
			fill_color = Color(1.0, 0.5, 0.1, 0.85)  ## Orange-red for alert
		else:
			fill_color = Color(1.0, 0.2, 0.2, 0.85)  ## Red for chase
		draw_arc(arc_center, arc_radius, arc_start, filled_end, arc_steps,
			fill_color, 4.0, true)

		## Percentage text
		var pct_text := "%d%%" % roundi(detection * 100.0)
		draw_string(
			ThemeDB.fallback_font,
			arc_center + Vector2(-12.0, 8.0),
			pct_text,
			HORIZONTAL_ALIGNMENT_CENTER,
			-1,
			10,
			Color(1.0, 1.0, 1.0, 0.95)
		)

