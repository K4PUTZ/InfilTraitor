extends Node2D
class_name ShadowOverlay

## Overlay permanente de sombras táticas.
## Escurece tiles em _shadow_tiles proporcionalmente ao multiplicador.
## Sempre visível — não depende de dev_vision.

var _room: Node          = null
var _floor_layer: TileMapLayer = null
var _visual_offset: Vector2 = Vector2.ZERO
var _shadow_tiles: Dictionary = {}

## Cores de sombra — neutro escuro, não azulado
## Sombra direta: escurecimento forte mas não opaco
const COLOR_SHADOW_FULL    := Color(0.0, 0.0, 0.0, 0.52)
## Penumbra: escurecimento leve, indica transição
const COLOR_SHADOW_PARTIAL := Color(0.0, 0.0, 0.0, 0.28)

## Dimensões do diamond isométrico (matching floor tile)
const TILE_HW := 128.0   ## metade da largura
const TILE_HH :=  64.0   ## metade da altura

func setup(room: Node, floor_layer: TileMapLayer, offset: Vector2) -> void:
	_room         = room
	_floor_layer  = floor_layer
	_visual_offset = offset

func update_shadow_tiles(shadow_tiles: Dictionary) -> void:
	_shadow_tiles = shadow_tiles
	queue_redraw()

func _draw() -> void:
	if _floor_layer == null or _shadow_tiles.is_empty():
		return
	for shadow_cell: Vector2i in _shadow_tiles.keys():
		var mult: float = _shadow_tiles[shadow_cell]
		var world_pos := _floor_layer.map_to_local(shadow_cell) + _visual_offset
		var diamond := PackedVector2Array([
			world_pos + Vector2(     0.0, -TILE_HH),
			world_pos + Vector2( TILE_HW,      0.0),
			world_pos + Vector2(     0.0,  TILE_HH),
			world_pos + Vector2(-TILE_HW,      0.0),
		])
		## Sombra direta vs penumbra determinada pelo valor do multiplicador
		## (Assume SHADOW_MULT=0.30 e PENUMBRA_MULT=0.55 do M2-11)
		var color := COLOR_SHADOW_FULL if mult <= 0.35 else COLOR_SHADOW_PARTIAL
		draw_colored_polygon(diamond, color)
