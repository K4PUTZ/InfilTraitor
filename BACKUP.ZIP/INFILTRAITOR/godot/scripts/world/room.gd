extends Node2D
## Tactical room controller: input, UI wiring, agent turns and scene setup.

const RoomLayoutBuilder = preload("res://godot/scripts/world/room_layout_builder.gd")
const LevelGraphClass    = preload("res://godot/scripts/world/level_graph.gd")
const GuardEnemyClass    = preload("res://godot/scripts/agents/guard_enemy.gd")

@onready var floor_layer:         TileMapLayer = $FloorLayer
@onready var turn_manager = $TurnManager
@onready var enemy_phase_controller = $EnemyPhaseController
@onready var enemies_root:         Node2D       = $Enemies
@onready var movement_overlay = $MovementOverlay
@onready var path_preview = $PathPreview
@onready var structure_wall_layer:       TileMapLayer = $StructureWallLayer
@onready var structure_wall_upper_layer: TileMapLayer = $StructureWallUpperLayer
@onready var structure_layer:            TileMapLayer = $StructureLayer
@onready var selection_overlay:   Node2D       = $SelectionOverlay
@onready var agent:               DebugAgent   = $Agent
@onready var tile_labels_overlay: Node2D       = $TileLabelsOverlay
@onready var camera:              Camera2D     = $Camera2D
@onready var btn_numbers:         Button       = $HUD/TopBar/Row/BtnNumbers
@onready var btn_fullscreen:      Button       = $HUD/TopBar/Row/BtnFullscreen
@onready var btn_viewport:        Button       = $HUD/TopBar/Row/BtnViewport
@onready var btn_reset:           Button       = $HUD/TopBar/Row/BtnReset
@onready var btn_perspective_nw:  Button       = $HUD/PerspectivePad/Grid/BtnPerspectiveNW
@onready var btn_perspective_ne:  Button       = $HUD/PerspectivePad/Grid/BtnPerspectiveNE
@onready var btn_perspective_sw:  Button       = $HUD/PerspectivePad/Grid/BtnPerspectiveSW
@onready var btn_perspective_se:  Button       = $HUD/PerspectivePad/Grid/BtnPerspectiveSE
@onready var lbl_ap:              Label        = $HUD/TopBar/Row/LblAp
@onready var chk_auto_end_turn:   CheckBox        = $HUD/TopBar/Row/BtnEndTurn/Content/ChkAutoEndTurn
@onready var btn_end_turn:        Button          = $HUD/TopBar/Row/BtnEndTurn
@onready var lbl_alert:           Label           = $HUD/TopBar/Row/LblAlert
@onready var busted_dialog:       Label           = $HUD/BustedDialog
@onready var enemy_turn_banner:   Control         = $HUD/EnemyTurnBanner
@onready var fog_of_war:          Node2D          = $FogOfWarOverlay
@onready var _fog_rect:           ColorRect       = $VisionFogOverlay/FogRect

const TILESET_PATH := "res://godot/resources/tilesets/tileset_blocks.tres"
const INVALID_CELL := Vector2i(-9999, -9999)

## The TileMap renders the current 512px-tall source tiles lower than the
## logical grid used by map_to_local/local_to_map. Compensate with one fixed
## visual offset so camera, labels, selection and picking all agree.
const VISUAL_GRID_OFFSET := Vector2(0.0, 512.0)

## tile_name → TileSet source_id
var _tile_ids: Dictionary = {}
var _room_size: Vector2i = Vector2i.ZERO
var _blocked_cells: Dictionary = {}
var _base_layout: Dictionary = {}
var _current_blocked_edges: Array[Dictionary] = []
var _guards: Array = []

## Camera drag state (left mouse — drag vs click distinguished by threshold)
const DRAG_THRESHOLD_SQ := 64.0   ## 8 px squared

var _left_down:        bool    = false
var _drag_started:     bool    = false
var _drag_start_mouse: Vector2 = Vector2.ZERO
var _drag_start_cam:   Vector2 = Vector2.ZERO

## Zoom limits and step
const ZOOM_MIN  := 0.20
const ZOOM_MAX  := 1.20
const ZOOM_STEP := 0.06

## Vision & FOW radii — independent of each other:
## VISION_TILE_RADIUS  controls only the shader gradient (live clear-circle around agent).
## FOW_REVEAL_RADIUS   controls how many tiles get permanently revealed each move,
##                     and is also the hard limit of the camera leash.
const VISION_TILE_RADIUS := 5      ## shader gradient radius (tiles)
const FOW_REVEAL_RADIUS  := 9      ## FOW reveal radius + camera leash hard limit (tiles)
const CAMERA_SOFT_ZONE_TILES := 2  ## tiles of ease-out damping before leash hard stop
const WORLD_TILE_PX          := 128.0  ## horizontal px per isometric tile step

## Pinch-zoom state (mobile two-finger)
var _touches:         Dictionary = {}   ## finger_index → screen position
var _pinch_last_dist: float      = 0.0

## Viewport toggle state
var _is_desktop_viewport: bool = false
var _pending_auto_end_turn: bool = false
var _selected_cell: Vector2i = INVALID_CELL
var _active_perspective: String = "N"
var _alert_meter: int = 0

const ALERT_MAX := 100
const ALERT_GAIN_WARNING := 20
const ALERT_GAIN_FULL := 45

const ENEMY_INTER_TURN_DELAY := 1.0
const ENEMY_CAMERA_TWEEN_DURATION := 0.45
const ENEMY_PHASE_MAX_OPEN_ZOOM := 0.65
const ACTOR_END_HOLD_DELAY := 0.5

var _actor_end_pause_active: bool = false

const _PERSPECTIVE_SUFFIX_MAP := {
	"N": {"NE": "NE", "SE": "SE", "SW": "SW", "NW": "NW"},
	"E": {"NE": "SE", "SE": "SW", "SW": "NW", "NW": "NE"},
	"S": {"NE": "SW", "SE": "NW", "SW": "NE", "NW": "SE"},
	"W": {"NE": "NW", "SE": "NE", "SW": "SE", "NW": "SW"},
}

## Vision bonus added by agent abilities; combined with the player vision radius.
var vision_bonus_tiles: int = 0
var _agent_start_cell: Vector2i = Vector2i.ZERO
var _agent_start_cell_base: Vector2i = Vector2i.ZERO
var _debug_show_enemies: bool = false

## Position of this segment in the 3×3 level grid (gx, gy in 0..2).
## Set before _ready() runs (e.g. by the level controller or via the Inspector).
## Controls which exits LevelGraph assigns; default (1,1) = centre segment (all exits open).
@export var segment_grid_pos: Vector2i = Vector2i(1, 1)
## Seed for the level graph random generator. Match across all 9 segments in a level.
@export var level_seed: int = 0


func _ready() -> void:
	var ts: TileSet = load(TILESET_PATH)
	if ts == null:
		push_error("TileSet not found: " + TILESET_PATH)
		return

	floor_layer.tile_set = ts
	structure_wall_layer.tile_set = ts
	structure_wall_upper_layer.tile_set = ts
	structure_layer.tile_set = ts
	_build_registry(ts)

	var graph: LevelGraph = LevelGraphClass.new()
	var connections: Dictionary = graph.generate(level_seed)
	var access_points: Array = LevelGraphClass.access_points_for(connections, segment_grid_pos)

	var layout_builder = RoomLayoutBuilder.new()
	var layout: Dictionary = layout_builder.build_layout(access_points)
	_base_layout = layout.duplicate(true)
	_agent_start_cell_base = layout.get("agent_start_cell", Vector2i.ZERO)
	_room_size = layout.get("size", Vector2i.ZERO)
	if _room_size == Vector2i.ZERO:
		push_error("Room layout did not provide a valid map size.")
		return

	var view_layout := _layout_with_perspective(_base_layout, _active_perspective)
	_room_size = view_layout.get("size", _room_size)
	_build_room(view_layout)
	var agent_start_cell: Vector2i = view_layout.get("agent_start_cell", Vector2i.ZERO)
	_agent_start_cell = agent_start_cell
	_center_camera(agent_start_cell)

	## Give overlays their references.
	movement_overlay.setup(floor_layer, VISUAL_GRID_OFFSET, turn_manager.MOVE_POINTS_PER_AP)
	movement_overlay.set_blocked_cells(_build_navigation_blocked_cells())
	var blocked_edges: Array[Dictionary] = []
	for e in view_layout.get("blocked_edges", []):
		blocked_edges.append(e)
	_current_blocked_edges = blocked_edges.duplicate(true)
	movement_overlay.set_blocked_edges(blocked_edges)
	path_preview.setup(floor_layer, VISUAL_GRID_OFFSET)
	selection_overlay.floor_layer = floor_layer
	selection_overlay.visual_offset = VISUAL_GRID_OFFSET

	agent.setup(floor_layer, VISUAL_GRID_OFFSET, agent_start_cell)
	_spawn_guards(view_layout.get("enemy_defs", []))
	fog_of_war.setup(floor_layer, VISUAL_GRID_OFFSET, _room_size)
	fog_of_war.reveal_around(agent_start_cell, FOW_REVEAL_RADIUS + vision_bonus_tiles)
	tile_labels_overlay.floor_layer = floor_layer
	tile_labels_overlay.visual_offset = VISUAL_GRID_OFFSET
	tile_labels_overlay.room_w = _room_size.x
	tile_labels_overlay.room_h = _room_size.y
	tile_labels_overlay.visible = false
	btn_numbers.modulate = Color(1.0, 1.0, 1.0, 0.35)
	camera.ignore_rotation = true
	camera.rotation_degrees = 0.0

	turn_manager.ap_changed.connect(_on_ap_changed)
	turn_manager.enemy_phase_started.connect(_on_enemy_phase_started)
	agent.move_started.connect(_on_agent_move_started)
	agent.step_finished.connect(_on_agent_step_finished)
	agent.move_finished.connect(_on_agent_move_finished)
	btn_end_turn.pressed.connect(_on_btn_end_turn)
	btn_numbers.pressed.connect(_on_btn_numbers)
	btn_fullscreen.pressed.connect(_on_btn_fullscreen)
	btn_viewport.pressed.connect(_on_btn_viewport)
	btn_reset.pressed.connect(_on_btn_reset)
	btn_perspective_nw.pressed.connect(func() -> void: _set_perspective("W"))
	btn_perspective_ne.pressed.connect(func() -> void: _set_perspective("N"))
	btn_perspective_sw.pressed.connect(func() -> void: _set_perspective("S"))
	btn_perspective_se.pressed.connect(func() -> void: _set_perspective("E"))
	_selected_cell = agent.cell
	selection_overlay.set_selected(agent.cell)
	turn_manager.reset_player_turn()
	_update_alert_label()
	enemy_turn_banner.visible = false
	_apply_debug_vision_state()
	_update_perspective_button_state()

	## Start in desktop mode — _is_desktop_viewport is false, so one call switches to desktop.
	_on_btn_viewport()


func _set_perspective(direction: String) -> void:
	if not _PERSPECTIVE_SUFFIX_MAP.has(direction):
		return
	if _active_perspective == direction:
		_update_perspective_button_state()
		return

	var prev_direction := _active_perspective
	var base_agent := _cell_to_base(agent.cell, prev_direction)
	var has_selected := _selected_cell != INVALID_CELL
	var base_selected := _cell_to_base(_selected_cell, prev_direction) if has_selected else INVALID_CELL

	_active_perspective = direction
	if not _base_layout.is_empty():
		var view_layout := _layout_with_perspective(_base_layout, _active_perspective)
		_room_size = view_layout.get("size", _room_size)
		_agent_start_cell = view_layout.get("agent_start_cell", _agent_start_cell)
		_build_room(view_layout)
		_spawn_guards(view_layout.get("enemy_defs", []))
		movement_overlay.set_blocked_cells(_build_navigation_blocked_cells())
		var blocked_edges: Array[Dictionary] = []
		for e in view_layout.get("blocked_edges", []):
			blocked_edges.append(e)
		_current_blocked_edges = blocked_edges.duplicate(true)
		movement_overlay.set_blocked_edges(blocked_edges)

		tile_labels_overlay.room_w = _room_size.x
		tile_labels_overlay.room_h = _room_size.y

		var next_agent := _cell_from_base(base_agent, _active_perspective)
		if not _is_cell_inside_room(next_agent):
			next_agent = _agent_start_cell
		agent.set_cell(next_agent)

		if has_selected:
			var next_selected := _cell_from_base(base_selected, _active_perspective)
			_selected_cell = next_selected if _is_selectable_cell(next_selected) else next_agent
		else:
			_selected_cell = next_agent
		selection_overlay.set_selected(_selected_cell)

		fog_of_war.setup(floor_layer, VISUAL_GRID_OFFSET, _room_size)
		fog_of_war.reveal_around(agent.cell, FOW_REVEAL_RADIUS + vision_bonus_tiles)
		_apply_debug_vision_state()
		_center_camera(agent.cell)
		_refresh_tactical_state()
	_update_perspective_button_state()


func _update_perspective_button_state() -> void:
	var active_mod := Color(1.0, 1.0, 1.0, 1.0)
	var inactive_mod := Color(1.0, 1.0, 1.0, 0.45)
	btn_perspective_nw.modulate = active_mod if _active_perspective == "W" else inactive_mod
	btn_perspective_ne.modulate = active_mod if _active_perspective == "N" else inactive_mod
	btn_perspective_sw.modulate = active_mod if _active_perspective == "S" else inactive_mod
	btn_perspective_se.modulate = active_mod if _active_perspective == "E" else inactive_mod


func _center_camera(focus_cell: Vector2i) -> void:
	var centre_world := floor_layer.map_to_local(focus_cell) + Vector2(0.0, 64.0) + VISUAL_GRID_OFFSET
	camera.global_position = centre_world


func _on_btn_numbers() -> void:
	tile_labels_overlay.visible = not tile_labels_overlay.visible
	btn_numbers.modulate = Color.WHITE if tile_labels_overlay.visible else Color(1.0, 1.0, 1.0, 0.35)


func _on_btn_fullscreen() -> void:
	var mode := DisplayServer.window_get_mode()
	if mode == DisplayServer.WINDOW_MODE_FULLSCREEN or mode == DisplayServer.WINDOW_MODE_EXCLUSIVE_FULLSCREEN:
		DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_WINDOWED)
	else:
		DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_FULLSCREEN)


func _on_btn_end_turn() -> void:
	if agent.is_moving or turn_manager.is_enemy_phase or _actor_end_pause_active:
		return
	_pending_auto_end_turn = false
	turn_manager.end_turn()


func _on_btn_reset() -> void:
	if agent.is_moving or turn_manager.is_enemy_phase or _actor_end_pause_active:
		return
	_pending_auto_end_turn = false
	enemy_turn_banner.visible = false
	agent.set_cell(_agent_start_cell)
	for guard in _guards:
		if is_instance_valid(guard):
			guard.reset_to_route_start()
	_selected_cell = _agent_start_cell
	selection_overlay.set_selected(_agent_start_cell)
	fog_of_war.reset_fog()
	fog_of_war.reveal_around(_agent_start_cell, FOW_REVEAL_RADIUS + vision_bonus_tiles)
	_center_camera(_agent_start_cell)
	movement_overlay.clear_overlay()
	path_preview.clear_path()
	_alert_meter = 0
	_update_alert_label()
	turn_manager.reset_player_turn()


func _on_btn_viewport() -> void:
	_is_desktop_viewport = not _is_desktop_viewport
	var target := Vector2i(1280, 720) if _is_desktop_viewport else Vector2i(390, 844)
	btn_viewport.text = "D" if _is_desktop_viewport else "M"

	## Exit fullscreen first — can't resize while in fullscreen.
	if DisplayServer.window_get_mode() != DisplayServer.WINDOW_MODE_WINDOWED:
		DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_WINDOWED)

	## Resize the OS window.
	DisplayServer.window_set_size(target)

	## Change the logical canvas resolution so the camera sees the right world area.
	## Without this, canvas_items stretch just scales the fixed 390×844 base to fill the window.
	get_tree().root.content_scale_size = target

	## Center on screen after resize.
	var screen_size := DisplayServer.screen_get_size()
	var centered := Vector2(screen_size - target) / 2.0
	DisplayServer.window_set_position(Vector2i(centered.round()))


func _on_ap_changed(current_ap: int, max_ap: int) -> void:
	lbl_ap.text = "INIMIGOS" if turn_manager.is_enemy_phase else "AP %d/%d" % [current_ap, max_ap]
	if not agent.is_moving:
		_refresh_tactical_state()


func _on_agent_move_started(_from_cell: Vector2i, to_cell: Vector2i) -> void:
	selection_overlay.set_selected(to_cell)
	movement_overlay.clear_overlay()
	path_preview.clear_path()


func _on_agent_step_finished(step_cell: Vector2i) -> void:
	fog_of_war.reveal_around(step_cell, FOW_REVEAL_RADIUS + vision_bonus_tiles)


func _on_agent_move_finished(_cell: Vector2i) -> void:
	_selected_cell = agent.cell
	selection_overlay.set_selected(agent.cell)
	_update_enemy_visibility()
	if _pending_auto_end_turn:
		_pending_auto_end_turn = false
		turn_manager.end_turn()
		return
	_refresh_tactical_state()


func _refresh_tactical_state() -> void:
	movement_overlay.set_blocked_cells(_build_navigation_blocked_cells())
	movement_overlay.rebuild(agent.cell, turn_manager.get_max_move_points())
	_update_selected_preview()
	_update_enemy_visibility()


func _on_enemy_phase_started() -> void:
	if _guards.is_empty():
		turn_manager.finish_enemy_phase()
		return
	enemy_turn_banner.visible = true
	movement_overlay.clear_overlay()
	path_preview.clear_path()
	selection_overlay.set_selected(agent.cell)
	var first_guard := _first_valid_guard_cell()
	if first_guard != INVALID_CELL:
		await _focus_camera_for_enemy_phase(first_guard)
	await _hold_actor_end_pause()
	await _run_enemy_phase()
	enemy_turn_banner.visible = false
	if _alert_meter >= ALERT_MAX:
		await _show_busted_dialog()
		_alert_meter = 0
		agent.set_cell(_agent_start_cell)
		for guard in _guards:
			if is_instance_valid(guard):
				guard.reset_to_route_start()
		_selected_cell = _agent_start_cell
		selection_overlay.set_selected(_agent_start_cell)
		fog_of_war.reset_fog()
		fog_of_war.reveal_around(_agent_start_cell, FOW_REVEAL_RADIUS + vision_bonus_tiles)
	_update_alert_label()
	turn_manager.finish_enemy_phase()


func _run_enemy_phase() -> void:
	var blocked_edges: Dictionary = enemy_phase_controller.build_blocked_edge_set(_current_blocked_edges)
	var occupied: Dictionary = {}
	for guard in _guards:
		if is_instance_valid(guard):
			occupied[guard.cell] = guard

	var max_severity := 0
	for i in range(_guards.size()):
		var guard = _guards[i]
		if not is_instance_valid(guard):
			continue

		var report: Dictionary = await enemy_phase_controller.run_single_guard_turn(
			guard,
			agent.cell,
			_blocked_cells,
			blocked_edges,
			_room_size,
			occupied
		)
		max_severity = maxi(max_severity, int(report.get("max_severity", 0)))
		await _hold_actor_end_pause()

		var next_focus := _next_enemy_phase_focus_cell(i)
		await _enemy_inter_turn_pause_with_camera(next_focus)

	if max_severity == 1:
		_alert_meter = mini(ALERT_MAX, _alert_meter + ALERT_GAIN_WARNING)
	elif max_severity >= 2:
		_alert_meter = mini(ALERT_MAX, _alert_meter + ALERT_GAIN_FULL)

	_update_alert_label()
	_update_enemy_visibility()


func _enemy_inter_turn_pause_with_camera(target_cell: Vector2i) -> void:
	var tween_time := minf(ENEMY_CAMERA_TWEEN_DURATION, ENEMY_INTER_TURN_DELAY)
	await _focus_camera_for_enemy_phase(target_cell, tween_time)
	var remain := ENEMY_INTER_TURN_DELAY - tween_time
	if remain > 0.0:
		await get_tree().create_timer(remain).timeout


func _hold_actor_end_pause() -> void:
	_actor_end_pause_active = true
	await get_tree().create_timer(ACTOR_END_HOLD_DELAY).timeout
	_actor_end_pause_active = false


func _focus_camera_for_enemy_phase(target_cell: Vector2i, duration: float = ENEMY_CAMERA_TWEEN_DURATION) -> void:
	if target_cell == INVALID_CELL:
		return
	var target_world := _world_center_for_cell(target_cell)
	var target_zoom := camera.zoom.x
	if target_zoom > ENEMY_PHASE_MAX_OPEN_ZOOM:
		target_zoom = ENEMY_PHASE_MAX_OPEN_ZOOM

	var tween := create_tween()
	tween.set_parallel(true)
	tween.set_trans(Tween.TRANS_SINE)
	tween.set_ease(Tween.EASE_IN_OUT)
	tween.tween_property(camera, "global_position", target_world, duration)
	tween.tween_property(camera, "zoom", Vector2(target_zoom, target_zoom), duration)
	await tween.finished


func _world_center_for_cell(cell: Vector2i) -> Vector2:
	return floor_layer.map_to_local(cell) + Vector2(0.0, 64.0) + VISUAL_GRID_OFFSET


func _first_valid_guard_cell() -> Vector2i:
	for guard in _guards:
		if is_instance_valid(guard):
			return guard.cell
	return INVALID_CELL


func _next_enemy_phase_focus_cell(current_guard_idx: int) -> Vector2i:
	for i in range(current_guard_idx + 1, _guards.size()):
		var next_guard = _guards[i]
		if is_instance_valid(next_guard):
			return next_guard.cell
	return agent.cell


func _update_alert_label() -> void:
	lbl_alert.text = "ALERTA %d%%" % _alert_meter
	var t := float(_alert_meter) / float(ALERT_MAX)
	lbl_alert.modulate = Color(1.0, 1.0 - 0.55 * t, 1.0 - 0.75 * t, 1.0)


func _show_busted_dialog() -> void:
	busted_dialog.text = "Busted"
	busted_dialog.visible = true
	await get_tree().create_timer(1.2).timeout
	busted_dialog.visible = false


func _toggle_debug_show_enemies() -> void:
	_debug_show_enemies = not _debug_show_enemies
	_apply_debug_vision_state()


func _apply_debug_vision_state() -> void:
	fog_of_war.visible = not _debug_show_enemies
	_fog_rect.visible = not _debug_show_enemies
	_update_enemy_visibility()


func _spawn_guards(enemy_defs: Array) -> void:
	for child in enemies_root.get_children():
		child.queue_free()
	_guards.clear()

	for i in range(enemy_defs.size()):
		var entry: Dictionary = enemy_defs[i]
		var route: Array[Vector2i] = []
		for c in entry.get("route", []):
			route.append(c)
		if route.size() < 2:
			continue

		var guard = GuardEnemyClass.new()
		enemies_root.add_child(guard)
		guard.setup(
			floor_layer,
			VISUAL_GRID_OFFSET,
			String(entry.get("id", "guard_%d" % (i + 1))),
			route,
			int(entry.get("start_index", 0))
		)
		_guards.append(guard)

	_update_enemy_visibility()


func _build_navigation_blocked_cells() -> Array[Vector2i]:
	var nav: Array[Vector2i] = _get_blocked_cells_array()
	for guard in _guards:
		if not is_instance_valid(guard):
			continue
		if guard.cell == agent.cell:
			continue
		nav.append(guard.cell)
	return nav


func _is_guard_cell(cell: Vector2i) -> bool:
	for guard in _guards:
		if is_instance_valid(guard) and guard.cell == cell:
			return true
	return false


func _update_enemy_visibility() -> void:
	# Update enemy alpha/saturation each frame while moving.
	# Visibility is driven by the player's vision radius + ability bonuses.
	# At vision distance the guard starts to desaturate, then fades out one tile later.
	if _debug_show_enemies:
		for guard in _guards:
			if not is_instance_valid(guard):
				continue
			guard.modulate.a = 1.0
		queue_redraw()
		return

	var enemy_vision := float(agent.get_vision_radius() + vision_bonus_tiles)
	for guard in _guards:
		if not is_instance_valid(guard):
			continue
		var d: float = (guard.cell - agent.cell).length()
		var tile_distance: int = int(floor(d + 0.5))
		if tile_distance <= int(enemy_vision) - 1:
			guard.modulate = Color(1.0, 1.0, 1.0, 1.0)
		elif tile_distance == int(enemy_vision):
			guard.modulate = Color(0.85, 0.85, 0.85, 1.0)
		elif tile_distance == int(enemy_vision) + 1:
			guard.modulate = Color(0.65, 0.65, 0.65, 0.5)
		else:
			guard.modulate = Color(1.0, 1.0, 1.0, 0.0)
	queue_redraw()


func _draw() -> void:
	for guard in _guards:
		if not is_instance_valid(guard):
			continue
		if guard.last_known_agent_cell == INVALID_CELL:
			continue
		if guard.state == guard.STATE_PATROL:
			continue
		var world := _world_center_for_cell(guard.last_known_agent_cell)
		draw_circle(world, 18.0, Color(1.0, 0.72, 0.18, 0.24))
		draw_circle(world, 18.0, Color(1.0, 0.9, 0.2, 0.82), 3.0)
		draw_line(world + Vector2(-8.0, 0.0), world + Vector2(8.0, 0.0), Color(1.0, 1.0, 1.0, 0.92), 2.5)
		draw_line(world + Vector2(0.0, -8.0), world + Vector2(0.0, 8.0), Color(1.0, 1.0, 1.0, 0.92), 2.5)


func _update_selected_preview() -> void:
	if _selected_cell == INVALID_CELL or _selected_cell == agent.cell:
		path_preview.clear_path()
		return

	if not movement_overlay.is_reachable(_selected_cell):
		path_preview.clear_path()
		return

	var path: Array[Vector2i] = movement_overlay.build_path_to(_selected_cell)
	if path.size() < 2:
		path_preview.clear_path()
		return

	path_preview.set_path(path, movement_overlay.get_ap_cost(_selected_cell))


func _is_selectable_cell(cell: Vector2i) -> bool:
	if cell == INVALID_CELL or _blocked_cells.has(cell) or _is_guard_cell(cell):
		return false
	return floor_layer.get_cell_source_id(cell) != -1


func _set_selected_cell(cell: Vector2i) -> void:
	if not _is_selectable_cell(cell):
		return
	_selected_cell = cell
	selection_overlay.set_selected(cell)
	_update_selected_preview()


func _handle_tile_click(cell: Vector2i) -> void:
	if turn_manager.is_enemy_phase or _actor_end_pause_active:
		return
	if not _is_selectable_cell(cell):
		path_preview.clear_path()
		return

	if _selected_cell != cell:
		_set_selected_cell(cell)
		return

	if cell != agent.cell and _try_move_to(cell):
		return

	_update_selected_preview()


func _try_move_to(cell: Vector2i) -> bool:
	if _actor_end_pause_active:
		return false
	if turn_manager.is_enemy_phase:
		return false
	if agent.is_moving or cell == INVALID_CELL or cell == agent.cell:
		return false
	if not movement_overlay.is_reachable(cell):
		return false

	var path_cost: int = movement_overlay.get_cost(cell)
	## Build path before spending AP — spend triggers ap_changed → rebuild → clears _costs.
	var path: Array[Vector2i] = movement_overlay.build_path_to(cell)
	if path.size() < 2:
		return false
	if not turn_manager.spend_for_path_cost(path_cost):
		return false

	_selected_cell = cell
	_pending_auto_end_turn = chk_auto_end_turn.button_pressed and int(turn_manager.current_ap) <= 0
	agent.move_along_path(path)
	return true


## Build a name → source_id dictionary from TileSet custom data.
func _build_registry(ts: TileSet) -> void:
	for i in ts.get_source_count():
		var sid := ts.get_source_id(i)
		var src := ts.get_source(sid) as TileSetAtlasSource
		if src == null:
			continue
		var td := src.get_tile_data(Vector2i(0, 0), 0)
		if td:
			_tile_ids[td.get_custom_data("tile_name")] = sid
	print("[Room] %d tiles registered." % _tile_ids.size())


## Place a named tile at cell. Silent no-op for unknown names.
func _place(cell: Vector2i, tile_name: String, layer: TileMapLayer = floor_layer) -> void:
	var sid: int = _tile_ids.get(tile_name, -1)
	if sid != -1:
		layer.set_cell(cell, sid, Vector2i(0, 0))


func _build_room(layout: Dictionary) -> void:
	floor_layer.clear()
	structure_wall_layer.clear()
	structure_wall_upper_layer.clear()
	structure_layer.clear()

	var floor_tile_name := String(layout.get("floor_tile_name", "floor_SE"))
	## Extend floor 1 cell beyond the map boundary so the outer faces of border
	## walls sit on ground instead of floating over dark background.
	for x in range(-1, _room_size.x + 1):
		for y in range(-1, _room_size.y + 1):
			_place(Vector2i(x, y), floor_tile_name)

	for structure_entry in layout.get("wall_tiles", []):
		var wall_cell: Vector2i = structure_entry.get("cell", INVALID_CELL)
		var wall_tile_name := String(structure_entry.get("tile_name", ""))
		_place(wall_cell, wall_tile_name, structure_wall_layer)

	## Place upper-layer wall tiles for double-height walls
	for structure_entry in layout.get("wall_tiles_upper", []):
		var wall_cell: Vector2i = structure_entry.get("cell", INVALID_CELL)
		var wall_tile_name := String(structure_entry.get("tile_name", ""))
		_place(wall_cell, wall_tile_name, structure_wall_upper_layer)

	for structure_entry in layout.get("structure_tiles", []):
		var cell: Vector2i = structure_entry.get("cell", INVALID_CELL)
		var tile_name := String(structure_entry.get("tile_name", ""))
		_place(cell, tile_name, structure_layer)

	_cache_blocked_cells(layout)


func _cache_blocked_cells(layout: Dictionary) -> void:
	_blocked_cells.clear()
	for cell in layout.get("blocked_cells", []):
		_blocked_cells[cell] = true


func _get_blocked_cells_array() -> Array[Vector2i]:
	var cells: Array[Vector2i] = []
	for cell in _blocked_cells.keys():
		cells.append(cell)
	return cells


func _is_cell_inside_room(cell: Vector2i) -> bool:
	return cell.x >= 0 and cell.y >= 0 and cell.x < _room_size.x and cell.y < _room_size.y


func _layout_with_perspective(layout: Dictionary, direction: String) -> Dictionary:
	var mapped := layout.duplicate(true)
	var base_size: Vector2i = layout.get("size", Vector2i.ZERO)
	var rotated_size: Vector2i = _rotated_size(base_size, direction)
	mapped["size"] = rotated_size
	mapped["agent_start_cell"] = _cell_from_base(layout.get("agent_start_cell", Vector2i.ZERO), direction, base_size)
	mapped["floor_tile_name"] = _remap_tile_name_for_perspective(
		String(layout.get("floor_tile_name", "floor_SE")), direction)

	for key in ["wall_tiles", "wall_tiles_upper", "structure_tiles"]:
		var src: Array = layout.get(key, [])
		var dst: Array = []
		for entry in src:
			var out := (entry as Dictionary).duplicate(true)
			out["cell"] = _cell_from_base(out.get("cell", INVALID_CELL), direction, base_size)
			out["tile_name"] = _remap_tile_name_for_perspective(String(out.get("tile_name", "")), direction)
			dst.append(out)
		mapped[key] = dst

	var blocked_cells: Array[Vector2i] = []
	for cell in layout.get("blocked_cells", []):
		blocked_cells.append(_cell_from_base(cell, direction, base_size))
	mapped["blocked_cells"] = blocked_cells

	var blocked_edges: Array[Dictionary] = []
	for edge in layout.get("blocked_edges", []):
		blocked_edges.append({
			"from": _cell_from_base(edge.get("from", Vector2i.ZERO), direction, base_size),
			"to": _cell_from_base(edge.get("to", Vector2i.ZERO), direction, base_size),
		})
	mapped["blocked_edges"] = blocked_edges

	var enemy_defs: Array[Dictionary] = []
	for enemy in layout.get("enemy_defs", []):
		var out := (enemy as Dictionary).duplicate(true)
		var route: Array[Vector2i] = []
		for cell in enemy.get("route", []):
			route.append(_cell_from_base(cell, direction, base_size))
		out["route"] = route
		enemy_defs.append(out)
	mapped["enemy_defs"] = enemy_defs
	return mapped


func _rotated_size(base_size: Vector2i, direction: String) -> Vector2i:
	if direction == "E" or direction == "W":
		return Vector2i(base_size.y, base_size.x)
	return base_size


func _cell_from_base(base_cell: Vector2i, direction: String, base_size: Vector2i = Vector2i.ZERO) -> Vector2i:
	if base_cell == INVALID_CELL:
		return INVALID_CELL
	var size := base_size
	if size == Vector2i.ZERO:
		size = _base_layout.get("size", Vector2i.ZERO)
	var w := size.x
	var h := size.y
	match direction:
		"E":
			return Vector2i(h - 1 - base_cell.y, base_cell.x)
		"S":
			return Vector2i(w - 1 - base_cell.x, h - 1 - base_cell.y)
		"W":
			return Vector2i(base_cell.y, w - 1 - base_cell.x)
		_:
			return base_cell


func _cell_to_base(view_cell: Vector2i, direction: String, base_size: Vector2i = Vector2i.ZERO) -> Vector2i:
	if view_cell == INVALID_CELL:
		return INVALID_CELL
	var size := base_size
	if size == Vector2i.ZERO:
		size = _base_layout.get("size", Vector2i.ZERO)
	var w := size.x
	var h := size.y
	match direction:
		"E":
			return Vector2i(view_cell.y, h - 1 - view_cell.x)
		"S":
			return Vector2i(w - 1 - view_cell.x, h - 1 - view_cell.y)
		"W":
			return Vector2i(w - 1 - view_cell.y, view_cell.x)
		_:
			return view_cell


func _remap_tile_name_for_perspective(tile_name: String, direction: String) -> String:
	if tile_name.is_empty():
		return tile_name
	var i := tile_name.rfind("_")
	if i < 0:
		return tile_name
	var base := tile_name.substr(0, i)
	var suffix := tile_name.substr(i + 1)
	if not _PERSPECTIVE_SUFFIX_MAP.has(direction):
		return tile_name
	var suffix_map: Dictionary = _PERSPECTIVE_SUFFIX_MAP[direction]
	if not suffix_map.has(suffix):
		return tile_name
	return "%s_%s" % [base, String(suffix_map[suffix])]


## Convert a screen-space press position to the tile cell underneath it.
## local_to_map uses the TOP VERTEX as anchor, so it only gives the correct
## cell when clicking the top quadrant. The 3×3 search over visual CENTERs
## (map_to_local + Vector2(0,64)) finds the diamond that truly contains the
## click — this corrects the other three quadrants.
func _screen_to_tile(screen_pos: Vector2) -> Vector2i:
	var ct: Transform2D = get_viewport().get_canvas_transform()
	var lp: Vector2 = floor_layer.to_local(ct.affine_inverse() * screen_pos)
	var logical_lp := lp - VISUAL_GRID_OFFSET
	var tile_seed: Vector2i = floor_layer.local_to_map(logical_lp)
	var best := tile_seed
	var best_dist := INF
	var found_inside := false
	for dc: int in [-1, 0, 1]:
		for dr: int in [-1, 0, 1]:
			var c := tile_seed + Vector2i(dc, dr)
			var center := floor_layer.map_to_local(c) + Vector2(0.0, 64.0) + VISUAL_GRID_OFFSET
			var d := lp - center
			var dist := absf(d.x) / 128.0 + absf(d.y) / 64.0
			if dist <= 1.0 and dist < best_dist:
				best_dist = dist
				best = c
				found_inside = true
	if found_inside:
		return best
	return INVALID_CELL


## Apply zoom clamped between ZOOM_MIN and ZOOM_MAX.
func _apply_zoom(new_z: float) -> void:
	camera.zoom = Vector2(new_z, new_z)


func _process(_delta: float) -> void:
	_update_vision_fog()
	if _has_moving_guards():
		_update_enemy_visibility()


func _has_moving_guards() -> bool:
	for guard in _guards:
		if is_instance_valid(guard) and guard.is_moving:
			return true
	return false


## Update the distance-fog shader uniforms every frame so the gradient tracks
## the agent's screen position and scales correctly with zoom and viewport size.
func _update_vision_fog() -> void:
	var mat := _fog_rect.material as ShaderMaterial
	if mat == null:
		return
	## Use global_position so the gradient tracks the visual agent during step animation.
	var agent_world := agent.global_position
	var canvas_t    := get_viewport().get_canvas_transform()
	var vp_size     := get_viewport().get_visible_rect().size
	var screen_px   := canvas_t * agent_world
	var screen_uv   := screen_px / vp_size
	var zoom        := camera.zoom.x
	## Gradient: tight clear center (3 tiles), outer boundary pushes 9 tiles
	## beyond the FOW reveal for a very long, gradual fade into darkness.
	var vision_r_px := float(VISION_TILE_RADIUS + vision_bonus_tiles) * WORLD_TILE_PX * zoom
	var outer_uv    := (vision_r_px + 9.0 * WORLD_TILE_PX * zoom) / vp_size.y
	var inner_uv    := maxf(0.0, vision_r_px - 3.0 * WORLD_TILE_PX * zoom) / vp_size.y
	mat.set_shader_parameter("agent_screen_uv", screen_uv)
	mat.set_shader_parameter("fog_inner_uv",    inner_uv)
	mat.set_shader_parameter("fog_outer_uv",    outer_uv)


## Return a camera position constrained to the vision leash around the agent.
## Inside the soft zone the camera decelerates (quadratic ease-out);
## beyond the hard limit it is clamped to the boundary.
func _get_leashed_pos(proposed: Vector2) -> Vector2:
	var hard_radius := float(FOW_REVEAL_RADIUS + vision_bonus_tiles) * WORLD_TILE_PX
	var soft_radius := hard_radius - float(CAMERA_SOFT_ZONE_TILES) * WORLD_TILE_PX
	var agent_world := floor_layer.map_to_local(agent.cell) + Vector2(0.0, 64.0) + VISUAL_GRID_OFFSET
	var offset      := proposed - agent_world
	var dist        := offset.length()
	if dist <= soft_radius:
		return proposed
	if dist >= hard_radius:
		return agent_world + offset.normalized() * hard_radius
	## Soft zone: quadratic ease-out — slows as camera approaches the hard limit.
	var t      := (dist - soft_radius) / (hard_radius - soft_radius)   ## 0..1
	var damped := soft_radius + (hard_radius - soft_radius) * t * (2.0 - t)
	return agent_world + offset.normalized() * damped


## Unified input: wheel zoom · pinch zoom · motion drag.
## Left mouse button (press/release) lives in _unhandled_input so GUI
## controls (Buttons) can consume their clicks before game logic runs.
func _input(event: InputEvent) -> void:
	if event is InputEventKey:
		var key := event as InputEventKey
		if key.pressed and not key.echo and key.keycode == KEY_V:
			_toggle_debug_show_enemies()
			return

	## ── Touch: track fingers for pinch-zoom ─────────────────────────────
	if event is InputEventScreenTouch:
		var st := event as InputEventScreenTouch
		if st.pressed:
			_touches[st.index] = st.position
		else:
			_touches.erase(st.index)
			_pinch_last_dist = 0.0
		if _touches.size() >= 2:
			_left_down = false
			_drag_started = false
		get_viewport().set_input_as_handled()
		return

	if event is InputEventScreenDrag:
		var sd := event as InputEventScreenDrag
		_touches[sd.index] = sd.position
		if _touches.size() == 2:
			var keys := _touches.keys()
			var dist := (_touches[keys[0]] as Vector2).distance_to(_touches[keys[1]])
			if _pinch_last_dist > 0.0:
				var delta := (dist - _pinch_last_dist) * 0.001
				_apply_zoom(clampf(camera.zoom.x + delta, ZOOM_MIN, ZOOM_MAX))
			_pinch_last_dist = dist
			get_viewport().set_input_as_handled()
		return

	## ── Mouse wheel zoom ─────────────────────────────────────────────────
	if event is InputEventMouseButton:
		var mb := event as InputEventMouseButton
		if mb.button_index == MOUSE_BUTTON_WHEEL_UP and mb.pressed:
			_apply_zoom(clampf(camera.zoom.x + ZOOM_STEP, ZOOM_MIN, ZOOM_MAX))
			get_viewport().set_input_as_handled()
		elif mb.button_index == MOUSE_BUTTON_WHEEL_DOWN and mb.pressed:
			_apply_zoom(clampf(camera.zoom.x - ZOOM_STEP, ZOOM_MIN, ZOOM_MAX))
			get_viewport().set_input_as_handled()
		return

	## ── Mouse motion: pan when dragging ─────────────────────────────────
	if event is InputEventMouseMotion and _left_down and _touches.size() < 2:
		var mm := event as InputEventMouseMotion
		var moved_sq := (mm.position - _drag_start_mouse).length_squared()
		if not _drag_started and moved_sq > DRAG_THRESHOLD_SQ:
			_drag_started = true
		if _drag_started:
			var delta := (mm.position - _drag_start_mouse) / camera.zoom.x
			camera.global_position = _get_leashed_pos(_drag_start_cam - delta)
			get_viewport().set_input_as_handled()
		return


## Left mouse: only runs when no GUI Control consumed the event first.
## This lets HUD buttons work while still handling pan + tile selection.
func _unhandled_input(event: InputEvent) -> void:
	if turn_manager.is_enemy_phase or _actor_end_pause_active:
		return
	if not event is InputEventMouseButton:
		return
	var mb := event as InputEventMouseButton
	if mb.button_index != MOUSE_BUTTON_LEFT or _touches.size() >= 2:
		return

	if mb.pressed:
		_left_down = true
		_drag_started = false
		_drag_start_mouse = mb.position
		_drag_start_cam = camera.global_position
	else:
		if not _drag_started:
			var cell := _screen_to_tile(mb.position)
			_handle_tile_click(cell)
		_left_down = false
		_drag_started = false