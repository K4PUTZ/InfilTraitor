# Sessão de Design — 2026-06-24
## Resumo Executivo para Próxima Conversa

---

## Estado ao Inicio da Sessão

- Codebase INFILTRAITOR em Godot 4/GDScript, arquitetura hub-and-spoke com 6 controllers
- Pipeline de assets usando pack Kenney como base + masters gerados em `master_assets/`
- `generate_master_walls.py` existente com bug conhecido em `_draw_top` e `_draw_end`
- Discutindo oclusão de paredes e sistema de iluminação de faces

---

## Decisões Tomadas (em ordem cronológica)

### 1. Oclusão de paredes
- Fade localizado: paredes imediatamente na frente do agente + 2 laterais
- Tween 0.5s por subcubo individual via `ShaderMaterial`
- **Dither Bayer 4×4** em vez de alpha padrão (pixels sobreviventes 100% opacos)
- Agente sempre renderizado na frente (z-priority/stencil)
- Nota futura: stroke parcial na fronteira de oclusão

### 2. Subcubos como unidade arquitetural
- Paredes construídas de subcubos atômicos empilhados em N TileMapLayers
- Layer modulate para iluminação de face (per-layer, barato)
- Per-tile overlay para luzes próximas (precision mode)
- Até 28 layers (7 andares teóricos) — draw calls gerenciáveis

### 3. Remoção do Kenney
- `blocks-prototype/` e `master_assets/` removidos
- Pipeline single-source: `source_assets/` (scan recursivo)
- `build_tileset.gd` reescrito sem dual-path

### 4. Novo paradigma de assets — compositor PIL
- **Átomo:** `subcube_[material].png` (64×64px, cubo 1×1×1 flat-lit)
- **Shapes:** gerador Python faz `alpha_composite` de átomos em painter's order
- Nenhum cálculo de geometria nos shape generators — só composição de imagens
- Fórmulas canônicas de offset isométrico documentadas no Master Plan

### 5. Grid Resolution Migration — DECISÃO MAIS IMPORTANTE
**`CELL_SIZE` muda de `256×128` para `64×32`**
- 1 sub-tile = 1 tile de gameplay = 1 subcubo atômico
- Grid 4× mais fino (16× mais células)
- Personagem percorre mesma distância visual movendo `AGENT_STEP_CELLS = 4`
- Assets gerados (64×64) têm o tamanho correto SEM retrabalho
- Coordenadas de mapa ×4, raios/ranges ×4, valores de gameplay ×4

---

## Trabalho Completado (operador)

| Item | Status |
|---|---|
| `generate_subcube.py` | ✅ 4 materiais × 64×64 |
| `generate_wall.py` (compositor) | ✅ NW wall, offsets corretos |
| `subcube_concrete.png` | ✅ verificado |
| `wall_concrete.png` | ✅ verificado |

---

## Próximos Prompts (em ordem)

1. **SUB-00-B** — `build_tileset.gd` single-source, canvas 64×64, deletar Kenney
2. **SUB-00-C** — `generate_master_floor.py` (face top apenas)
3. **SUB-00-D** — `generate_master_block.py` (alias de subcube por ora)
4. **SUB-00-E** — Atualizar mapas (coords ×4, remover column/doorway)
5. **GRID-01-A** — `CELL_SIZE = Vector2i(64,32)`, `MAP_SIZE`, `INNER_ORIGIN`, `BUFFER`
6. **GRID-01-B** — Todos os Vector2i de posição nos mapas ×4
7. **GRID-01-C** — `AGENT_STEP_CELLS = 4`, TicSystem path tracing
8. **GRID-01-D** — Valores de gameplay ×4 (vision, hearing, light, shadow)

---

## Arquivos Críticos Gerados nesta Sessão

- `docs/production/SUBCUBE_MASTER_PLAN.md` — fonte de verdade completa
- `PROMPTS/SUB-00-A-wallFace-asset.md` — prompt concluído
- `tools/asset_generation/generate_subcube.py` — gerado pelo operador ✅
- `tools/asset_generation/generate_wall.py` — gerado pelo operador ✅

---

## Constantes Canônicas para Nova Conversa

```gdscript
const CELL_SIZE         := Vector2i(64, 32)
const MAP_SIZE          := Vector2i(112, 184)
const INNER_ORIGIN      := Vector2i(20, 20)
const BUFFER            := 20
const AGENT_STEP_CELLS  := 4
const SUBCUBES_PER_FLOOR := 4
const SUBCUBE_STEP_PX   := 39.5
const MAX_SUBCUBES      := 28
```

```python
# generate_subcube.py
TILE_HW, TILE_HH = 32, 16
CUBE_HEIGHT = 32
PNG_W, PNG_H = 64, 64
# bW âncora em (0, 48) no canvas 64×64

# Compositor NW wall:
# dest(u, h) = (u*32, 400 - u*16 - h*32)
# painter's order: u de 3→0, h de 0→max
```

---

## Perguntas Abertas para Próxima Sessão

- Qual material padrão para SIGMA-01? (concrete presumido)
- `WALL_FLOOR_STEP_PX` muda de 158 para 39.5 — auditar todos os usos no código
- Profiling do A* com 20.608 nós — quando testar no device?
- Sistema de paletas: quando implementar `generate_variants.py`?
