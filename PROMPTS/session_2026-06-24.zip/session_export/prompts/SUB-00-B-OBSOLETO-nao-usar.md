# INFILTRAITOR — SUB-00-B: Reorganizar pastas + registrar tiles master-only
## Pipeline de assets — `build_tileset.gd` + `source_assets/` + geradores

**Data:** 2026-06-24
**Fase:** SUB-00 — Fundação de Assets
**Depende de:** SUB-00-A completo (wallFace_*.png gerados em master_assets/walls/)

---

## ARQUIVOS A MODIFICAR
- `godot/scripts/tools/build_tileset.gd`
- `tools/asset_generation/generate_master_walls.py`
- `tools/asset_generation/generate_master_crate.py`
- `tools/persistent/OPERATOR_CONTEXT.md` (seção Master Assets)
- `docs/technical/ASSET_MAP.md` (seção Master Assets)

## OPERAÇÕES DE FILESYSTEM
- Criar estrutura `ASSETS/ISOMETRIC/source_assets/`
- Mover conteúdo de `ASSETS/ISOMETRIC/master_assets/`
- Deletar `ASSETS/ISOMETRIC/master_assets/` após verificação

## ARQUIVOS QUE SERÃO REGENERADOS AUTOMATICAMENTE
- `godot/resources/tilesets/tileset_blocks.tres`
- `godot/scripts/world/tile_registry.gd`

## ARQUIVOS QUE NÃO DEVEM SER TOCADOS
Todos os outros. Em especial: nenhum arquivo `.gd` em `godot/scripts/` exceto
`build_tileset.gd`, nenhum arquivo de cena `.tscn`.

---

## CONTEXTO

O `build_tileset.gd` opera com dois diretórios:

- **`TILES_PATH`** (`blocks-prototype/Isometric/`) — catálogo flat de PNGs do pack
  Kenney. Todo tile no `TileRegistry` precisa existir aqui. Não modificar.
- **`MASTER_PATH`** (`master_assets/`) — assets gerados que substituem texturas do
  catálogo. O scan é recursivo mas só provê texturas de *substituição* — não
  registra tiles novos.

`wallFace_*` são tiles novos (não existem no pack Kenney). Para aparecerem no
`TileRegistry`, o `build_tileset.gd` precisa ser modificado para registrar tiles
presentes em `MASTER_PATH` que não existam em `TILES_PATH`.

Esta sessão faz isso, reorganiza as pastas para refletir a nova taxonomia, e
atualiza os scripts de geração para os novos caminhos.

---

## PASSO 1 — Modificar `build_tileset.gd`

### 1a — Adicionar `wallFace` ao `TILE_PROPS`

Localizar o `const TILE_PROPS` (linha ~103). Dentro do bloco `# Walls`, adicionar
a entrada para `wallFace` após `"wallBattlement"`:

```gdscript
## ANTES (trecho do bloco Walls):
    "wall":                   {walkable=false, cover=true,  interactive=false},
    "wallHalf":               {walkable=false, cover=true,  interactive=false},
    "wallCorner":             {walkable=false, cover=true,  interactive=false},
    "wallCornerHalf":         {walkable=false, cover=true,  interactive=false},
    "wallCurve":              {walkable=false, cover=true,  interactive=false},
    "wallCurveHalf":          {walkable=false, cover=true,  interactive=false},
    "wallBattlement":         {walkable=false, cover=true,  interactive=false},
```

```gdscript
## DEPOIS (adicionar wallFace ao final do bloco Walls):
    "wall":                   {walkable=false, cover=true,  interactive=false},
    "wallHalf":               {walkable=false, cover=true,  interactive=false},
    "wallCorner":             {walkable=false, cover=true,  interactive=false},
    "wallCornerHalf":         {walkable=false, cover=true,  interactive=false},
    "wallCurve":              {walkable=false, cover=true,  interactive=false},
    "wallCurveHalf":          {walkable=false, cover=true,  interactive=false},
    "wallBattlement":         {walkable=false, cover=true,  interactive=false},
    "wallFace":               {walkable=false, cover=true,  interactive=false},
```

**Nota:** `wallFace` já herda o offset de `EDGE_VISUAL_OFFSETS` automaticamente
porque `_is_edge_aligned_tile` verifica `begins_with("wall")`. Nenhuma mudança
em `EDGE_ALIGNED_PREFIXES` ou `EDGE_ALIGNED_EXCLUSIONS` é necessária.

---

### 1b — Atualizar `MASTER_PATH`

Localizar a linha (linha ~26):
```gdscript
const MASTER_PATH   := "res://ASSETS/ISOMETRIC/master_assets/"
```

Substituir por:
```gdscript
const MASTER_PATH   := "res://ASSETS/ISOMETRIC/source_assets/"
```

---

### 1c — Registrar tiles master-only

Localizar o bloco `_build()` onde `files` é construído e `masters` é indexado
(linha ~237 aproximadamente). O bloco atual é:

```gdscript
    files.sort()  # deterministic source_id ordering

    # ── Index master assets (base_name → flat-lit texture) ────────────────────
    var masters := _scan_master_textures()
    if not masters.is_empty():
        print("[build_tileset] Master assets found: %s" % ", ".join(masters.keys()))

    # ── Register each tile ───────────────────────────────────────────────────
```

Substituir por:

```gdscript
    files.sort()  # deterministic source_id ordering — preserva IDs existentes

    # ── Index master assets (base_name → flat-lit texture) ────────────────────
    var masters := _scan_master_textures()
    if not masters.is_empty():
        print("[build_tileset] Master assets found: %s" % ", ".join(masters.keys()))

    # ── Append master-only tiles (não existem em TILES_PATH) ──────────────────
    # Tiles master-only recebem IDs ACIMA dos tiles provisórios, preservando
    # todos os IDs existentes. São ordenados alfabeticamente entre si.
    var master_only: Array[String] = []
    for key in masters:
        if not files.has(key + ".png"):
            master_only.append(key + ".png")
    master_only.sort()
    if not master_only.is_empty():
        print("[build_tileset] Master-only tiles (new): %s" % ", ".join(master_only))
    files.append_array(master_only)

    # ── Register each tile ───────────────────────────────────────────────────
```

---

### 1d — Corrigir o carregamento de textura para tiles master-only

Localizar no loop de registro a linha:
```gdscript
        if texture == null:
            texture = load(TILES_PATH + file_name)
        if texture == null:
            push_warning("[build_tileset] Cannot load: " + file_name)
            continue
```

Substituir por:
```gdscript
        if texture == null:
            var provisory := TILES_PATH + file_name
            if FileAccess.file_exists(provisory):
                texture = load(provisory)
        if texture == null:
            push_warning("[build_tileset] Cannot load texture: " + file_name)
            continue
```

**Motivo:** tiles master-only não existem em `TILES_PATH`, então
`load(TILES_PATH + file_name)` retornaria null e geraria um erro desnecessário.
A versão nova só tenta carregar de `TILES_PATH` se o arquivo existir lá.

---

## PASSO 2 — Criar estrutura `source_assets/`

Criar os seguintes diretórios (na máquina local, não em `res://`):

```
ASSETS/ISOMETRIC/source_assets/
ASSETS/ISOMETRIC/source_assets/faces/
ASSETS/ISOMETRIC/source_assets/legacy/
ASSETS/ISOMETRIC/source_assets/legacy/walls/
ASSETS/ISOMETRIC/source_assets/legacy/blocks/
ASSETS/ISOMETRIC/source_assets/props/
```

Comandos bash:
```bash
cd "/Volumes/Expansion/----- PESSOAL -----/PYTHON/INFILTRAITOR"
mkdir -p ASSETS/ISOMETRIC/source_assets/faces
mkdir -p ASSETS/ISOMETRIC/source_assets/legacy/walls
mkdir -p ASSETS/ISOMETRIC/source_assets/legacy/blocks
mkdir -p ASSETS/ISOMETRIC/source_assets/props
```

---

## PASSO 3 — Mover assets para a nova estrutura

```bash
cd "/Volumes/Expansion/----- PESSOAL -----/PYTHON/INFILTRAITOR"

# wallFace_* → faces/ (assets atômicos gerados em SUB-00-A)
mv ASSETS/ISOMETRIC/master_assets/walls/wallFace_*.png \
   ASSETS/ISOMETRIC/source_assets/faces/

# Demais walls → legacy/walls/ (large-format, gerados, multi-subcubo)
mv ASSETS/ISOMETRIC/master_assets/walls/*.png \
   ASSETS/ISOMETRIC/source_assets/legacy/walls/

# blocks/ → props/ e legacy/blocks/
# crate.png é direction-agnostic (omnidirectional) → props/
mv ASSETS/ISOMETRIC/master_assets/blocks/crate.png \
   ASSETS/ISOMETRIC/source_assets/props/

# Qualquer outro PNG em blocks/ → legacy/blocks/
# (Se blocks/ estiver vazio após mover crate.png, ignorar)
mv ASSETS/ISOMETRIC/master_assets/blocks/*.png \
   ASSETS/ISOMETRIC/source_assets/legacy/blocks/ 2>/dev/null || true
```

Verificar que `master_assets/` está vazio antes de deletar:
```bash
find ASSETS/ISOMETRIC/master_assets/ -name "*.png" | wc -l
# Deve retornar 0
```

Deletar o diretório:
```bash
rm -rf ASSETS/ISOMETRIC/master_assets/
```

---

## PASSO 4 — Atualizar `generate_master_walls.py`

O script tem um único `OUTPUT_DIR` que agora precisa virar dois caminhos:
`wallFace_*` vai para `faces/`, os demais para `legacy/walls/`.

Localizar o topo do script onde `OUTPUT_DIR` é definido:

```python
OUTPUT_DIR = os.path.join(
    "/Volumes/Expansion/----- PESSOAL -----/PYTHON/INFILTRAITOR",
    "ASSETS/ISOMETRIC/master_assets/walls",
)
```

Substituir por:

```python
_BASE = "/Volumes/Expansion/----- PESSOAL -----/PYTHON/INFILTRAITOR"
OUTPUT_FACES       = os.path.join(_BASE, "ASSETS/ISOMETRIC/source_assets/faces")
OUTPUT_LEGACY_WALLS = os.path.join(_BASE, "ASSETS/ISOMETRIC/source_assets/legacy/walls")
```

Localizar a função `generate(base_name, wall_h, vcubes)`. Adicionar o parâmetro
`output_dir` com default para `OUTPUT_LEGACY_WALLS`:

```python
## ANTES:
def generate(base_name, wall_h, vcubes):
    ...
    path = os.path.join(OUTPUT_DIR, f"{base_name}_{direction}.png")

## DEPOIS:
def generate(base_name, wall_h, vcubes, output_dir=None):
    if output_dir is None:
        output_dir = OUTPUT_LEGACY_WALLS
    ...
    path = os.path.join(output_dir, f"{base_name}_{direction}.png")
```

Localizar o entry point `if __name__ == "__main__":`. Atualizar para usar os
novos diretórios:

```python
if __name__ == "__main__":
    os.makedirs(OUTPUT_FACES, exist_ok=True)
    os.makedirs(OUTPUT_LEGACY_WALLS, exist_ok=True)

    print("wall (160 px, 4 bands):")
    generate("wall", WALL_HEIGHT, VCUBES_FULL)              # → OUTPUT_LEGACY_WALLS

    print("wallHalf (80 px, 2 bands):")
    generate("wallHalf", HALF_HEIGHT, VCUBES_HALF)          # → OUTPUT_LEGACY_WALLS

    print("wallFace (40 px, 1 band — atomic subcube):")
    generate("wallFace", 40, 1, OUTPUT_FACES)               # → OUTPUT_FACES

    print("\n✓ Done — 12 master wall PNGs written to source_assets/")
    print("  Next: run build_tileset.gd to rebuild tileset_blocks.tres")
```

---

## PASSO 5 — Atualizar `generate_master_crate.py`

Abrir `tools/asset_generation/generate_master_crate.py`. Localizar o `OUTPUT_DIR`
(ou equivalente). Atualizar para apontar para `source_assets/props/`:

O padrão exato varia — buscar por `master_assets` no arquivo e substituir pelo
novo caminho `source_assets/props`. Se o arquivo usar uma variável `OUTPUT_DIR`,
substituir o valor. Se usar um path literal, substituir o path.

---

## PASSO 6 — Atualizar documentação

### `tools/persistent/OPERATOR_CONTEXT.md` — seção "Master Assets Folder"

Localizar a seção com header `### Master Assets Folder`. Atualizar:
- `master_assets/` → `source_assets/` em todos os lugares
- Atualizar a estrutura de pastas para refletir `faces/`, `legacy/walls/`,
  `legacy/blocks/`, `props/`
- A nota "Critical property: each master PNG is positioned on its canvas..." permanece inalterada

### `docs/technical/ASSET_MAP.md` — seção "Master Assets System"

Localizar a seção com header `## Master Assets System`. Atualizar:
- `master_assets/` → `source_assets/` em todos os lugares
- Atualizar o diagrama de estrutura de pastas para refletir a nova hierarquia

---

## PASSO 7 — Rebuild do TileSet

```bash
cd "/Volumes/Expansion/----- PESSOAL -----/PYTHON/INFILTRAITOR"
/Applications/Godot.app/Contents/MacOS/Godot --headless --path . \
  --script godot/scripts/tools/build_tileset.gd
```

Output esperado (excerpt):
```
[build_tileset] Starting...
[build_tileset] Master assets found: wall_NW, wall_NE, wall_SW, wall_SE, ...
[build_tileset] Master-only tiles (new): wallFace_NE.png, wallFace_NW.png, wallFace_SE.png, wallFace_SW.png
[build_tileset] Saved TileSet → res://godot/resources/tilesets/tileset_blocks.tres  (244 tiles)
[build_tileset] Saved registry → res://godot/scripts/world/tile_registry.gd
[build_tileset] Done.
```

(244 = 240 tiles Kenney + 4 wallFace novos. O número exato pode variar se o pack
Kenney tiver contagem diferente — o importante é que seja 4 a mais que antes.)

---

## ACCEPTANCE TESTS

**Teste 1 — Nova estrutura de pastas:**
```bash
ls ASSETS/ISOMETRIC/source_assets/faces/
# wallFace_NE.png  wallFace_NW.png  wallFace_SE.png  wallFace_SW.png

ls ASSETS/ISOMETRIC/source_assets/legacy/walls/
# wall_NE.png  wall_NW.png  wall_SE.png  wall_SW.png  wallHalf_*.png  wallCorner_*.png  wallCornerHalf_*.png

ls ASSETS/ISOMETRIC/source_assets/props/
# crate.png

ls ASSETS/ISOMETRIC/master_assets/ 2>/dev/null && echo "ERRO: master_assets ainda existe"
# Deve retornar erro (dir não existe) — se retornar output, reportar
```

**Teste 2 — wallFace registrado:**
```bash
grep "wallFace_" godot/scripts/world/tile_registry.gd
```
Deve retornar 4 linhas (NE, NW, SE, SW). Os IDs devem ser maiores que todos os
IDs existentes (≥ 240 se o pack Kenney tem 240 tiles).

**Teste 3 — IDs existentes preservados (regressão crítica):**
```bash
git diff godot/scripts/world/tile_registry.gd | grep "^-" | grep -v "^---"
```
Não deve haver linhas removidas (apenas adições de `wallFace_*`). Se qualquer ID
existente mudou, parar e reportar antes de continuar.

**Teste 4 — Tileset count:**
```bash
grep -c '": [0-9]' godot/scripts/world/tile_registry.gd
```
Deve ser o número anterior (240) + 4 = 244. Se o número anterior era diferente,
verificar que é exatamente 4 a mais.

**Teste 5 — Propriedades de wallFace no tileset:**
```python
# Rodar no Python para verificar custom data do tile
# (opcional mas recomendado para confirmar walkable=false, cover=true)
import subprocess
result = subprocess.run(['grep', '-A1', 'wallFace_NW', 
                        'godot/scripts/world/tile_registry.gd'], 
                       capture_output=True, text=True)
print(result.stdout)
```
Alternativamente: abrir o Godot, ir ao TileSet inspector e confirmar que
`wallFace_NW` tem `walkable=false`, `cover=true`, `interactive=false`.

**Teste 6 — Jogo abre sem erros:**
Confirmar que a cena principal carrega sem erros no painel Problems e sem
erros no Output durante o boot.

**Teste 7 — Generator produz nos novos paths:**
```bash
python3 tools/asset_generation/generate_master_walls.py
ls ASSETS/ISOMETRIC/source_assets/faces/wallFace_NW.png   # deve existir
ls ASSETS/ISOMETRIC/source_assets/legacy/walls/wall_NW.png # deve existir
```

---

## NOTAS PARA O OPERADOR

1. **IDs existentes NÃO devem mudar.** Tiles master-only são appendados ao FINAL
   do array `files` depois do sort de TILES_PATH, garantindo que os IDs
   0–(N-1) do pack Kenney permanecem inalterados.

2. **O `FileAccess.file_exists()` é necessário** porque tiles master-only não
   existem em `TILES_PATH`. Sem essa guarda, `load(TILES_PATH + file_name)`
   geraria um erro de resource no Godot.

3. **`generate_master_crate.py` pode ter estrutura diferente** de
   `generate_master_walls.py`. Ler o arquivo antes de modificar — não assumir
   que o padrão é idêntico.

4. **Se `master_assets/` não existir mais após os moves**, o build script
   com `MASTER_PATH` apontando para `source_assets/` precisa encontrar os
   assets lá. Verificar que os moves foram completos antes de rodar o rebuild.

5. **Não renomear tiles existentes.** `wall_NW`, `wallHalf_NW` etc. permanecem
   com os mesmos nomes em `legacy/walls/` — o `build_tileset.gd` encontra pelo
   nome do arquivo, independente do subfolder.
